package com.pt.a2.ui;

public interface RefreshableFrame {
    void refresh(Object o);
}
