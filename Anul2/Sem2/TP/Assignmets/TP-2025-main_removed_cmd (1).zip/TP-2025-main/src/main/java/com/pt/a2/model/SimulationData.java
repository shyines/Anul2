package com.pt.a2.model;

import com.pt.a2.domain.dispatcher.SelectionPolicy;
import com.pt.a2.utils.Interval;

public class SimulationData {
    private int time;
    private Interval serviceTimeInterval;
    private Interval arrivalTimeInterval;
    private int qCount;
    private int clientCount;
    private SelectionPolicy selectionPolicy;

    public SimulationData(int time, Interval serviceTimeInterval, Interval arrivalTimeInterval, int qCount, int clientCount, SelectionPolicy selectionPolicy) {
        this.time = time;
        this.serviceTimeInterval = serviceTimeInterval;
        this.arrivalTimeInterval = arrivalTimeInterval;
        this.qCount = qCount;
        this.clientCount = clientCount;
        this.selectionPolicy = selectionPolicy;
    }

    public int getTime() {
        return time;
    }

    public Interval getServiceTimeInterval() {
        return serviceTimeInterval;
    }

    public Interval getArrivalTimeInterval() {
        return arrivalTimeInterval;
    }

    public int getqCount() {
        return qCount;
    }

    public int getClientCount() {
        return clientCount;
    }

    public SelectionPolicy getSelectionPolicy() {
        return selectionPolicy;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setServiceTimeInterval(Interval serviceTimeInterval) {
        this.serviceTimeInterval = serviceTimeInterval;
    }

    public void setArrivalTimeInterval(Interval arrivalTimeInterval) {
        this.arrivalTimeInterval = arrivalTimeInterval;
    }

    public void setqCount(int qCount) {
        this.qCount = qCount;
    }

    public void setClientCount(int clientCount) {
        this.clientCount = clientCount;
    }

    public void setSelectionPolicy(SelectionPolicy selectionPolicy) {
        this.selectionPolicy = selectionPolicy;
    }
}
