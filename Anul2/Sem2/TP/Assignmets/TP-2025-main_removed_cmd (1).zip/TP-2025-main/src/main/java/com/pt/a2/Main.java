package com.pt.a2;

import com.pt.a2.ui.SimulationFormFrame;


public class Main{

    public static void main(String[] args) {
        SimulationFormFrame frame = new SimulationFormFrame();
        frame.setVisible(true);
    }
}