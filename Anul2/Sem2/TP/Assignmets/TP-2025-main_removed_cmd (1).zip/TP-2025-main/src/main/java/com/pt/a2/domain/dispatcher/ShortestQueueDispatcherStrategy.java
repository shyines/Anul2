package com.pt.a2.domain.dispatcher;

import com.pt.a2.model.Client;
import com.pt.a2.model.Queue;

import java.util.List;

public class ShortestQueueDispatcherStrategy implements QueueDispatcherStrategy {

    @Override
    public void dispatch(List<Queue> queues, Client client) {
        var minQueue = queues.get(0);
        int min = minQueue.size();

        for (Queue q : queues) {
            if (q.size() < min) {
                min = q.size();
                minQueue = q;
            }
        }

        minQueue.add(client);
    }
}
