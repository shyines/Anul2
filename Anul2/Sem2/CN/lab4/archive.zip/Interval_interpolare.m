function [a,b]=Interval_interpolare(tipex)
%functie care "returneaza" intervalul de interpolare
switch tipex
    case 'ex1'
        a=-1;b=1;
    case 'ex2'
        a=-5;b=5;
end